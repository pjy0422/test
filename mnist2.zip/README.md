---
title: Mnist2
emoji: 🌖
colorFrom: red
colorTo: blue
sdk: gradio
sdk_version: 3.44.4
app_file: app.py
pinned: false
license: mit
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference
