import gradio as gr
from PIL import Image
from pathlib import Path
import matplotlib.pyplot as plt
from torchvision import transforms
import torch
from torch import nn
import torchvision
from torchvision import datasets
from torchvision.transforms import ToTensor
from model import cnn_classifier

title = "MNIST Classifer"
description = "MNIST classifier using a tinyVGG model"
article = "Created at 0920"

demo = gr.Interface()

class_names = ['0','1','2','3','4','5','6','7','8','9']

transform = transforms.Compose([
    transforms.Resize((28, 28)),  # Resize to 28x28 pixels
    transforms.Grayscale(num_output_channels=1),  # Convert to grayscale
    transforms.ToTensor()  # Convert to a PyTorch tensor
])

model = cnn_classifier(1,10,10)
model.load_state_dict(torch.load('model.pth'))
model = model.cpu()




def predict(img):
    img = transform(img).unsqueeze(0)
    model.eval()
    with torch.inference_mode():
        pred_probs = torch.softmax(model(img),dim=1)
    pred_labels_and_probs = {class_names[i]: float(pred_probs[0][i]) for i in range(len(class_names))}
    return pred_labels_and_probs


demo = gr.Interface(fn=predict, # mapping function from input to output
                    inputs=gr.Image(type="pil"), # what are the inputs?
                    outputs=[gr.Label(num_top_classes=3, label="Predictions"), # what are the outputs?
                             gr.Number(label="Prediction time (s)")], # our fn has two outputs, therefore we have two outputs
                    # Create examples list from "examples/" directory
                    title=title,
                    description=description,
                    article=article)
demo.launch()
